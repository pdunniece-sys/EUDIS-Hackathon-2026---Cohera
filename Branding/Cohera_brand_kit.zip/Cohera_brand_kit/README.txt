COHERA BRAND KIT
================

COLOURS (hex)
  Ink navy      13233A   main text, dark slides, the emblem
  Cream         ECE6D8   slide and page background
  Paper         E7E3DA   cards and tinted panels
  Signal amber  E9A23B   accents on dark, markers, the "ket" on dark
  Ket ochre     C47F17   accents on light, the "ket" on light, key numbers
  Slate         39475A   secondary text, labels
  INS red       9C3A2E   baseline / "INS only" / failure, used sparingly
  Hairline      CFC7B5   rules and card outlines

FONTS (all free, SIL Open Font License; install from fonts/ before opening the deck.
  The Chakra Petch files here are the basic Latin set; for accented capitals get the full family from fonts.google.com)
  Chakra Petch   headings and the COHERA wordmark
  IBM Plex Sans  body text
  IBM Plex Mono  labels, taglines, data (letter-spaced capitals)

LOGOS (transparent PNG, logos/)
  lockup-light / lockup-dark          |COHERA>  for light / dark backgrounds
  lockup-tag-light / lockup-tag-dark  with QUANTUM NAVIGATION underneath
  emblem-full                         Bloch-sphere emblem, for light backgrounds
  emblem-ondark                       same, deeper fill, for navy backgrounds
  emblem-icon                         simplified emblem for small sizes (headers, favicons)
  Keep clear space of one bar-height around the lockup. Don't recolour or stretch.

PLOTS
  plt.style.use("cohera.mplstyle") gives cream background, navy/ochre/red series,
  left-aligned titles and no top/right spines, matching the deck.
  Convention: truth = navy, Cohera result = ochre, INS-only baseline = red dashed.

TELLUS ATTRIBUTION (required wherever Tellus data appears)
  "Contains Irish Public Sector Data (Geological Survey Ireland) licensed under a
   Creative Commons Attribution 4.0 International (CC BY 4.0) licence."
